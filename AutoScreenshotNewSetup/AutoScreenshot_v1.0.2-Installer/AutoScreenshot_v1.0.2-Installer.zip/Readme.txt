1. Extract all Files
2. Run AutoScreenshotSetup.exe
3. Follow Installer Instructions
4. Done
